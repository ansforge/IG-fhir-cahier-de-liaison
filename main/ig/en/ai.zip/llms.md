# ans.fhir.fr.cdl#3.0.0: Cahier De Liaison(en)

## Pages

* [Accueil](index.md)
* [Suppression d'une note](suppr_note.md)
* [Création d'une note](creation_note.md)
* [Construction Des Flux](construction_des_flux.md)
* [M-à-j d'une note](maj_note.md)
* [Specifications Techniques](specifications_techniques.md)
* [Recherche d'une note](recherche_note.md)
* [Historique des changements](changes.md)
* [Spécifications fonctionnelles](specifications_fonctionnelles.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Resource Profiles

* [Bundle de création d'une note](StructureDefinition-cdl-bundle-creation-note.md)
* [Bundle de mise à jour d'une note](StructureDefinition-cdl-bundle-maj-note.md)
* [Bundle résultat recherche notes](StructureDefinition-cdl-bundle-resultat-recherche-notes.md)
* [DocumentReference Cahier de Liaison](StructureDefinition-cdl-document-reference.md)

### Extensions

* [CdL_isEmergency](StructureDefinition-cdl-ext-is-emergency.md)

### CapabilityStatements

* [CI-SIS Cahier-de-Liaison - ConsommateurContenu](CapabilityStatement-ConsommateurContenu.md)
* [CI-SIS Cahier-de-Liaison - CreateurContenu](CapabilityStatement-CreateurContenu.md)
* [CI-SIS Cahier-de-Liaison - GestionnaireCdL](CapabilityStatement-GestionnaireCdL.md)

### ConceptMaps

* [MOS to FHIR CDL](ConceptMap-ConceptMap-mos-cdl.md)

### ImplementationGuides

* [Cahier De Liaison](ImplementationGuide-ans.fhir.fr.cdl.md)

### Examples

* [cdl-bundle-creation-note (Bundle)](Bundle-cdl-bundle-creation-note.md)
* [0d920958-b596-4b91-af67-9bafc707820b (Patient)](Patient-0d920958-b596-4b91-af67-9bafc707820b.md)
